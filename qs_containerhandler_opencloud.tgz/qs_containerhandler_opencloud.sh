#!/usr/bin/env bash
# qs_containerhandler_opencloud.sh - OpenCloud container handler

# The following two lines are used for debugging purposes
# exec 1>/var/log/qs/debug_opencloud_container 2>&1
# set -x

##############################################################################
# ------------------- script-specific constants ---------------------------- #
##############################################################################
CONTAINERTAG="opencloud"
CONTAINERDESC="OpenCloud Server Handler"
VERSION="v1.0"
COPYRIGHT="Copyright (c) 2026 OSNexus Corporation"

APPNAME="qs_containerhandler_${CONTAINERTAG}"
APPDESC="$APPNAME $VERSION - $CONTAINERDESC"

##############################################################################
# ---------------- import container handler shared functions --------------- #
##############################################################################

LIB_DIR="$(cd -- "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=qs_containerlib.sh
source "${LIB_DIR}/qs_containerlib.sh"

##############################################################################
# -------------------------- container specific logic ---------------------- #
##############################################################################

usage()
{
  printf "\nExamples:\n\n"
  printf "    $APPNAME.sh run-container -c opencloud-service -s /mnt/storage-pools/qs-ID/opencloud-data -d /var/lib/opencloud -i opencloudeu/opencloud:4.0.3 -o \"opencloud_port:9200,config_dir:opencloud-config,network_name:opencloud-net,network_subnet:192.168.99.0/24,network_gateway:192.168.99.1,parent_interface:eth0,container_ip:192.168.99.10\"\n"
  printf "\n"
}

get_context_from_bindsrc() {
    # BINDSRC format: /mnt/containers/{rg_id}/opencloud/{svc_id}/shares/
    RESGRPID=$(echo "$BINDSRC" | cut -d'/' -f4)
    SVCID=$(echo "$BINDSRC" | cut -d'/' -f6)

    # Get Share ID from Resource Group
    SHAREID=$(qs resource-group-get --resource-group="$RESGRPID" --xml | xmllint --xpath "//resourceAssocList[objectType='53']/objectId/text()" -)

    # Get Mount Path from Share
    # Output format: "qs-{vol_id}/{share_name}"
    # We need raw output, so jq -r
    MOUNTPATH_RAW=$(qs share-get --share="$SHAREID" --json | jq -r '.mountPath')

    # Extract VOLID (Pool ID) and SHARENAME
    # MOUNTPATH_RAW example: qs-12345/my-share
    VOLID_STR=$(echo "$MOUNTPATH_RAW" | cut -d'/' -f1) # qs-12345
    SHARENAME=$(echo "$MOUNTPATH_RAW" | cut -d'/' -f2) # my-share

    # Strip 'qs-' from VOLID_STR to get raw ID
    VOLID=${VOLID_STR#qs-}

    # Export for use in main scope
    export RESGRPID SVCID SHAREID VOLID SHARENAME
}

# Required: run-container is executed to start the container
run-container()
{
    # Initialize variables
    OPENCLOUD_PORT="9200"
    CONFIG_DIR="opencloud-config"
    NETWORK_NAME=""
    NETWORK_SUBNET=""
    NETWORK_GATEWAY=""
    PARENT_INTERFACE=""
    CONTAINER_IP=""

    # Parse Options passed from QuantaStor
    IFS=',' read -ra OPT_ARR <<< "$OPTIONS"
    for opt in "${OPT_ARR[@]}"; do
        case "$opt" in
            opencloud_port:*) OPENCLOUD_PORT="${opt#opencloud_port:}" ;;
            config_dir:*) CONFIG_DIR="${opt#config_dir:}" ;;
            network_name:*) NETWORK_NAME="${opt#network_name:}" ;;
            network_subnet:*) NETWORK_SUBNET="${opt#network_subnet:}" ;;
            network_gateway:*) NETWORK_GATEWAY="${opt#network_gateway:}" ;;
            parent_interface:*) PARENT_INTERFACE="${opt#parent_interface:}" ;;
            container_ip:*) CONTAINER_IP="${opt#container_ip:}" ;;
        esac
    done

    # Populate context variables (VOLID, SHAREID, etc.) using qs CLI early
    get_context_from_bindsrc

    # Validate BINDSRC and find the single subdirectory (OpenCloud logic)
    if [[ -n "$BINDSRC" ]]; then
        # Find subdirectories in BINDSRC (non-recursive)
        # We use find to be robust, redirect stderr to null to avoid permission noise
        SUBDIRS_COUNT=$(find "$BINDSRC" -mindepth 1 -maxdepth 1 -type d | wc -l)
        
        if [[ "$SUBDIRS_COUNT" -ne 1 ]]; then
            logservice "ERROR" "Validation failed: BINDSRC '$BINDSRC' must contain exactly one subdirectory (the share). Found $SUBDIRS_COUNT."
            echo "ERROR: BINDSRC '$BINDSRC' must contain exactly one subdirectory. Found $SUBDIRS_COUNT." >&2
            exit 1
        fi

        # Get the single subdirectory path
        BINDSRC=$(find "$BINDSRC" -mindepth 1 -maxdepth 1 -type d | head -n 1)
        logservice "INFO" "Identified share directory: $BINDSRC"
    fi

    # Populate context variables (VOLID, SHAREID, etc.) using qs CLI if needed
    # get_context_from_bindsrc called earlier

    # Network Configuration (IPvlan)
    if [[ -n "$NETWORK_NAME" ]]; then
        # Check if network exists
        if ! docker network inspect "$NETWORK_NAME" >/dev/null 2>&1; then
            logservice "INFO" "Creating Docker network '$NETWORK_NAME' (ipvlan) on interface '$PARENT_INTERFACE'..."
            
            # Create ipvlan network with specified parameters
            docker network create -d ipvlan \
                --subnet="$NETWORK_SUBNET" \
                --gateway="$NETWORK_GATEWAY" \
                -o parent="$PARENT_INTERFACE" \
                "$NETWORK_NAME"
                
            if [[ $? -ne 0 ]]; then
                logservice "ERROR" "Failed to create Docker network '$NETWORK_NAME'."
                exit 1
            fi
        else
             logservice "INFO" "Docker network '$NETWORK_NAME' already exists. Using existing network."
        fi
    fi

    # Config Directory Setup
    if [[ -n "$CONFIG_DIR" && -n "$BINDSRC" ]]; then
        # Use VOLID (Pool ID) extracted from the share context
        CONFIG_PATH="/mnt/storage-pools/qs-${VOLID}/.container/${CONFIG_DIR}"
        logservice "INFO" "Constructed config path: $CONFIG_PATH"

        if [[ ! -d "$CONFIG_PATH" ]]; then
             logservice "ERROR" "Config directory not found at: $CONFIG_PATH"
             exit 1
        fi
    fi

    # Build docker run command
    DOCKER_CMD=(/usr/bin/docker run --restart=always -d)
    
    # Network settings
    if [[ -n "$NETWORK_NAME" ]]; then
        DOCKER_CMD+=(--net "$NETWORK_NAME")
    fi
    
    if [[ -n "$CONTAINER_IP" ]]; then
        DOCKER_CMD+=(--ip "$CONTAINER_IP")
    fi

    if [[ -n "$CONTAINERNAME" ]]; then
        DOCKER_CMD+=(--name "$CONTAINERNAME")
    fi

    # Add share bind mount (Data)
    # Mapping BINDSRC (the share root) to /var/lib/opencloud
    if [[ -n "$BINDSRC" ]]; then
       # Assuming OpenCloud uses /var/lib/opencloud for storage, or similar. 
       if [[ -n "$BINDDST" ]]; then
            DOCKER_CMD+=(--mount "type=bind,source=$BINDSRC,target=$BINDDST,bind-propagation=rslave")
       else
            DOCKER_CMD+=(--mount "type=bind,source=$BINDSRC,target=/var/lib/opencloud,bind-propagation=rslave")
       fi
    fi
    
    # Add Config bind mount
    # Mapping the config dir to OpenCloud's config location
    # Add Config bind mount
    # Mapping the config dir to OpenCloud's config location
    if [[ -n "$CONFIG_PATH" ]]; then
        # Example target: /etc/opencloud
        DOCKER_CMD+=(--mount "type=bind,source=$CONFIG_PATH,target=/etc/opencloud,bind-propagation=rslave")
    fi

    # Port mapping (if not using host networking/ipvlan logic where port mapping might not be needed if IP is unique)
    # With ipvlan, the container has its own IP, so -p host:container is usually not needed/doesn't work the same way.
    # But if we want to expose it, we can just let it listen on its port.
    # If NOT using ipvlan (e.g. bridge), we would need -p "$OPENCLOUD_PORT:80"
    
    # Env vars
    DOCKER_CMD+=(-e "OC_INSECURE=true")
    DOCKER_CMD+=(-e "PROXY_HTTP_ADDR=0.0.0.0:$OPENCLOUD_PORT")
    DOCKER_CMD+=(-e "OC_URL=https://$CONTAINER_IP:$OPENCLOUD_PORT")

    # Add container name and image
    [[ -n "$CONTAINER" ]] && DOCKER_CMD+=(--name "$CONTAINER")
    DOCKER_CMD+=("$CONTAINERIMAGE")

    # Execution Block
    if [[ "$DRY_RUN" == "1" ]]; then
        echo "TEST MODE: Action [Run Container]"
        echo "COMMAND: ${DOCKER_CMD[*]}"
    else
        if [[ "$VERBOSE" == "1" || "$DEBUG" == "1" ]]; then
            logservice "DEBUG" "${DOCKER_CMD[*]}"
        fi

        logservice "INFO" "Running container '${CONTAINERNAME}' with command '${DOCKER_CMD[*]}'."
        "${DOCKER_CMD[@]}"
    fi
}

##############################################################################
# ----------------------------- main entry --------------------------------- #
##############################################################################

ARGS=()
DRY_RUN=0
for arg in "$@"; do
    if [[ "$arg" == "--test" ]]; then
        DRY_RUN=1
    else
        ARGS+=("$arg")
    fi
done
set -- "${ARGS[@]}"

parse_cli OPERATION "$@"
dispatch "$OPERATION" run-container usage version
