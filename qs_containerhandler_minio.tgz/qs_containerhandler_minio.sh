#!/usr/bin/env bash
# qs_containerhandler_minio.sh - MinIO service container handler

# QuantaStor wants to pass a .../shares volume to the docker container
# that contains any number of bind mounts for all of the shares that
# are part of the resource group.  MinIO doesn't like that.  It doesn't
# deal with the bind mounts and errors out. This script accommidates
# that by looking into the path that QuantaStor passes in to determine
# if there is exactly 1 subdirectory.  If more it will error out.  If 1 it
# will change BINDSRC to use the subdirectory.

# The following two lines are used for debugging purposes
# exec 1>/var/log/qs/debug_minio_container 2>&1
# set -x

##############################################################################
# ------------------- script-specific constants ---------------------------- #
##############################################################################
CONTAINERTAG="minio"
CONTAINERDESC="MinIO Service Container Handler"
VERSION="v1.1"
COPYRIGHT="Copyright (c) 2025 OSNexus Corporation"

APPNAME="qs_containerhandler_${CONTAINERTAG}"
APPDESC="$APPNAME $VERSION - $CONTAINERDESC"

##############################################################################
# ---------------- import container handler shared functions --------------- #
##############################################################################

# Find the library next to this script; adjust if you store it elsewhere.
LIB_DIR="$(cd -- "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=qs_containerlib.sh
source "${LIB_DIR}/qs_containerlib.sh"

##############################################################################
# -------------------------- container specific logic ---------------------- #
##############################################################################

usage()
{
  printf "\nExamples:\n\n"
  printf "    $APPNAME.sh run-container -c myminio -b 10.0.0.1 -s /shares/src -d /data -i minio/minio:latest -o \"minio_root_user:admin,minio_root_password:password123\"
"
  printf "    $APPNAME.sh run-container --test ... (Dry run: prints command without executing)\n"
  printf "\n"
}

# Required, run-container is executed to start the container with the provided parameters.
run-container()
{
    # MinIO root user/pass, ports, and custom IP from options
    MINIO_ROOT_USER=""
    MINIO_ROOT_PASSWORD=""
    MINIO_API_PORT="9000"
    MINIO_CONSOLE_PORT="9001"
    MINIO_BIND_IP=""

    IFS=',' read -ra OPT_ARR <<< "$OPTIONS"
    for opt in "${OPT_ARR[@]}"; do
        case "$opt" in
            minio_root_user:*) MINIO_ROOT_USER="${opt#minio_root_user:}" ;;
            minio_root_password:*) MINIO_ROOT_PASSWORD="${opt#minio_root_password:}" ;;
            minio_bind_ip:*) MINIO_BIND_IP="${opt#minio_bind_ip:}" ;;
            minio_api_port:*) MINIO_API_PORT="${opt#minio_api_port:}" ;;
            minio_console_port:*) MINIO_CONSOLE_PORT="${opt#minio_console_port:}" ;;
        esac
    done

    # Validate BINDSRC and find the single subdirectory
    if [[ -n "$BINDSRC" ]]; then
        # Find subdirectories in BINDSRC (non-recursive)
        # We use find to be robust, redirect stderr to null to avoid permission noise
        SUBDIRS_COUNT=$(find "$BINDSRC" -mindepth 1 -maxdepth 1 -type d | wc -l)
        
        if [[ "$SUBDIRS_COUNT" -ne 1 ]]; then
            logservice "ERROR" "Validation failed: BINDSRC '$BINDSRC' must contain exactly one subdirectory (the share). Found $SUBDIRS_COUNT."
            echo "ERROR: BINDSRC '$BINDSRC' must contain exactly one subdirectory. Found $SUBDIRS_COUNT." >&2
            exit 1
        fi

        # Get the single subdirectory path
        BINDSRC=$(find "$BINDSRC" -mindepth 1 -maxdepth 1 -type d | head -n 1)
        logservice "INFO" "Identified share directory: $BINDSRC"
    fi

    # Determine which IPs to bind to.
    # If MINIO_BIND_IP is set via options, it takes precedence.
    # Otherwise, we use BINDADDR (passed via -b flag).
    TARGET_IPS=()
    if [[ -n "$MINIO_BIND_IP" ]]; then
        TARGET_IPS+=("$MINIO_BIND_IP")
    else
        # Split BINDADDR by comma or space into an array
        IFS=', ' read -r -a ADDR_ARRAY <<< "$BINDADDR"
        TARGET_IPS=("${ADDR_ARRAY[@]}")
    fi

    # Build docker run command
    DOCKER_CMD=(/usr/bin/docker run --restart=always -d)

    # Add port mappings for each target IP
    for addr in "${TARGET_IPS[@]}"; do
        [[ -z "$addr" ]] && continue
        DOCKER_CMD+=(-p "$addr:$MINIO_API_PORT:9000" -p "$addr:$MINIO_CONSOLE_PORT:9001")
    done

    # Add container specific environment variables
    [[ -n "$MINIO_ROOT_USER" ]] && DOCKER_CMD+=(-e "MINIO_ROOT_USER=$MINIO_ROOT_USER")
    [[ -n "$MINIO_ROOT_PASSWORD" ]] && DOCKER_CMD+=(-e "MINIO_ROOT_PASSWORD=$MINIO_ROOT_PASSWORD")

    # Add share bind mount point associated with the resource-group into the container at location BINDDST
    if [[ -n "$BINDSRC" && -n "$BINDDST" ]]; then
        DOCKER_CMD+=(--mount "type=bind,source=$BINDSRC,target=$BINDDST,bind-propagation=rslave")
    fi

    # Add container name and image into the run line to make it easier to identify
    [[ -n "$CONTAINERNAME" ]] && DOCKER_CMD+=(--name "$CONTAINERNAME")
    DOCKER_CMD+=("$CONTAINERIMAGE")

    # Add MinIO specific start command
    DOCKER_CMD+=(server "$BINDDST" --console-address ":9001")

    # EXECUTION BLOCK
    if [[ "$DRY_RUN" == "1" ]]; then
        echo "TEST MODE: Action [Run Container]"
        echo "COMMAND: ${DOCKER_CMD[*]}"
    else
        # Run the command
        if [[ "$VERBOSE" == "1" || "$DEBUG" == "1" ]]; then
            logservice "DEBUG" "${DOCKER_CMD[*]}"
        fi

        logservice "INFO" "Running container '${CONTAINERNAME}' with command '${DOCKER_CMD[*]}'."
        "${DOCKER_CMD[@]}"
    fi
}

##############################################################################
# ----------------------------- main entry --------------------------------- #
##############################################################################

# Pre-parse for --test flag to handle Dry Run mode
# We strip it from arguments before passing to parse_cli to avoid library errors
ARGS=()
DRY_RUN=0
for arg in "$@"; do
    if [[ "$arg" == "--test" ]]; then
        DRY_RUN=1
    else
        ARGS+=("$arg")
    fi
done
set -- "${ARGS[@]}"

parse_cli OPERATION "$@"           # populate globals & OPERATION
dispatch "$OPERATION" run-container usage version
