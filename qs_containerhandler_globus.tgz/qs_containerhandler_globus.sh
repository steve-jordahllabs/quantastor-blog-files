#!/usr/bin/env bash
# qs_containerhandler_globus.sh - Globus Connect Server container handler

# The following two lines are used for debugging purposes
exec 1>/var/log/qs/debug_globus_container 2>&1
set -x

##############################################################################
# ------------------- script-specific constants ---------------------------- #
##############################################################################
CONTAINERTAG="globus"
CONTAINERDESC="Globus Connect Server Handler"
VERSION="v1.1"
COPYRIGHT="Copyright (c) 2026 OSNexus Corporation"

APPNAME="qs_containerhandler_${CONTAINERTAG}"
APPDESC="$APPNAME $VERSION - $CONTAINERDESC"

##############################################################################
# ---------------- import container handler shared functions --------------- #
##############################################################################

LIB_DIR="$(cd -- "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=qs_containerlib.sh
source "${LIB_DIR}/qs_containerlib.sh"

##############################################################################
# -------------------------- container specific logic ---------------------- #
##############################################################################

usage()
{
  printf "\nExamples:\n\n"
  printf "    $APPNAME.sh run-container -c globus-service -s /mnt/storage-pools/qs-ID/globus-share -d /data -i jasonalt/globus-connect-server:latest -o \"public_ip:1.2.3.4,public_fqdn:globus.example.com,endpoint_domain:foo.gaccess.io,network_name:globus-net,network_subnet:192.168.99.0/24,network_gateway:192.168.99.1,parent_interface:eth0,metadata_dir:globus-meta,container_ip:192.168.99.10,container_hostname:globus-node\"\n"
  printf "\n"
}

get_context_from_bindsrc() {
    # BINDSRC format: /mnt/containers/{rg_id}/globus/{svc_id}/shares/
    RESGRPID=$(echo "$BINDSRC" | cut -d'/' -f4)
    SVCID=$(echo "$BINDSRC" | cut -d'/' -f6)

    # Get Share ID from Resource Group
    SHAREID=$(qs resource-group-get --resource-group="$RESGRPID" --xml | xmllint --xpath "//resourceAssocList[objectType='53']/objectId/text()" -)

    # Get Mount Path from Share
    # Output format: "qs-{vol_id}/{share_name}"
    # We need raw output, so jq -r
    MOUNTPATH_RAW=$(qs share-get --share="$SHAREID" --json | jq -r '.mountPath')

    # Extract VOLID (Pool ID) and SHARENAME
    # MOUNTPATH_RAW example: qs-12345/my-share
    VOLID_STR=$(echo "$MOUNTPATH_RAW" | cut -d'/' -f1) # qs-12345
    SHARENAME=$(echo "$MOUNTPATH_RAW" | cut -d'/' -f2) # my-share

    # Strip 'qs-' from VOLID_STR to get raw ID
    VOLID=${VOLID_STR#qs-}

    # Export for use in main scope
    export RESGRPID SVCID SHAREID VOLID SHARENAME
}

# Required: run-container is executed to start the container
run-container()
{
    # Initialize variables
    PUBLIC_IP=""
    PUBLIC_FQDN=""
    ENDPOINT_DOMAIN=""
    NETWORK_NAME=""
    NETWORK_SUBNET=""
    NETWORK_GATEWAY=""
    PARENT_INTERFACE=""
    METADATA_DIR=""
    CONTAINER_IP=""
    CONTAINER_HOSTNAME=""

    # Parse Options passed from QuantaStor
    IFS=',' read -ra OPT_ARR <<< "$OPTIONS"
    for opt in "${OPT_ARR[@]}"; do
        case "$opt" in
            public_ip:*) PUBLIC_IP="${opt#public_ip:}" ;;
            public_fqdn:*) PUBLIC_FQDN="${opt#public_fqdn:}" ;;
            endpoint_domain:*) ENDPOINT_DOMAIN="${opt#endpoint_domain:}" ;;
            network_name:*) NETWORK_NAME="${opt#network_name:}" ;;
            network_subnet:*) NETWORK_SUBNET="${opt#network_subnet:}" ;;
            network_gateway:*) NETWORK_GATEWAY="${opt#network_gateway:}" ;;
            parent_interface:*) PARENT_INTERFACE="${opt#parent_interface:}" ;;
            metadata_dir:*) METADATA_DIR="${opt#metadata_dir:}" ;;
            container_ip:*) CONTAINER_IP="${opt#container_ip:}" ;;
            container_hostname:*) CONTAINER_HOSTNAME="${opt#container_hostname:}" ;;
        esac
    done

    # Populate context variables (VOLID, SHAREID, etc.) using qs CLI
    get_context_from_bindsrc

    # Network Configuration
    if [[ -n "$NETWORK_NAME" ]]; then
        # Check if network exists
        if ! docker network inspect "$NETWORK_NAME" >/dev/null 2>&1; then
            logservice "INFO" "Creating Docker network '$NETWORK_NAME' (ipvlan) on interface '$PARENT_INTERFACE'..."
            
            # Create ipvlan network with specified parameters
            # Note: Using ipvlan allows the container to have its own IP on the physical network
            docker network create -d ipvlan \
                --subnet="$NETWORK_SUBNET" \
                --gateway="$NETWORK_GATEWAY" \
                -o parent="$PARENT_INTERFACE" \
                "$NETWORK_NAME"
                
            if [[ $? -ne 0 ]]; then
                logservice "ERROR" "Failed to create Docker network '$NETWORK_NAME'."
                exit 1
            fi
        else
             logservice "INFO" "Docker network '$NETWORK_NAME' already exists. Using existing network."
        fi
    fi

    # Metadata Directory Setup & Env File Generation
    if [[ -n "$METADATA_DIR" && -n "$BINDSRC" ]]; then
        # Use VOLID (Pool ID) extracted from the share context
        METADATA_PATH="/mnt/storage-pools/qs-${VOLID}/.container/${METADATA_DIR}"
        logservice "INFO" "Constructed metadata path: $METADATA_PATH"

        if [[ ! -d "$METADATA_PATH" ]]; then
            logservice "ERROR" "Metadata directory not found at: $METADATA_PATH"
            exit 1
        fi

        DEPLOYMENT_KEY_FILE="$METADATA_PATH/deployment-key.json"
        if [[ ! -f "$DEPLOYMENT_KEY_FILE" ]]; then
            logservice "ERROR" "deployment-key.json not found at: $DEPLOYMENT_KEY_FILE"
            exit 1
        fi

        # Extract Client ID and Secret using Python
        if command -v jq &>/dev/null; then
            CLIENT_ID=$(jq -r .client_id "$DEPLOYMENT_KEY_FILE")
            CLIENT_SECRET=$(jq -r .secret "$DEPLOYMENT_KEY_FILE")
        else
            logservice "ERROR" "jq is required to parse deployment-key.json but was not found."
            exit 1
        fi
        
        # Read the full content of the key file
        DEPLOYMENT_KEY_CONTENT=$(cat "$DEPLOYMENT_KEY_FILE")

        # Create the env file
        ENV_FILE="$METADATA_PATH/env"
        logservice "INFO" "Generating environment file at: $ENV_FILE"

        {
            echo "NODE_SETUP_ARGS=--ip-address $PUBLIC_IP"
            echo "GLOBUS_CLIENT_ID=$CLIENT_ID"
            echo "GLOBUS_CLIENT_SECRET=$CLIENT_SECRET"
            echo "DEPLOYMENT_KEY=$DEPLOYMENT_KEY_CONTENT"
        } > "$ENV_FILE"

    else
        logservice "ERROR" "Metadata Directory or Bind Source not specified. Cannot proceed."
        exit 1
    fi

    # Build docker run command
    DOCKER_CMD=(/usr/bin/docker run --restart=always -d)
    
    # Network settings
    if [[ -n "$NETWORK_NAME" ]]; then
        DOCKER_CMD+=(--net "$NETWORK_NAME")
    fi
    
    if [[ -n "$CONTAINER_IP" ]]; then
        DOCKER_CMD+=(--ip "$CONTAINER_IP")
    fi
    
    if [[ -n "$CONTAINER_HOSTNAME" ]]; then
        DOCKER_CMD+=(--hostname "$CONTAINER_HOSTNAME")
    fi
    
    if [[ -n "$ENDPOINT_DOMAIN" ]]; then
        DOCKER_CMD+=(--domainname "$ENDPOINT_DOMAIN")
    fi

    if [[ -n "$CONTAINERNAME" ]]; then
        DOCKER_CMD+=(--name "$CONTAINERNAME")
    fi

    # ADD ENV FILE
    if [[ -f "$ENV_FILE" ]]; then
        DOCKER_CMD+=(--env-file "$ENV_FILE")
    fi

    # Add share bind mount
    if [[ -n "$BINDSRC" && -n "$BINDDST" ]]; then
        DOCKER_CMD+=(--mount "type=bind,source=$BINDSRC,target=$BINDDST,bind-propagation=rslave")
    fi
    
    # Add entrypoint script bind mount (Read-Only)
    # We verify the file exists in the METADATA_PATH before trying to mount it
    if [[ -n "$METADATA_PATH" && -f "$METADATA_PATH/entrypoint.sh" ]]; then
        logservice "INFO" "Mounting entrypoint.sh from $METADATA_PATH/entrypoint.sh"
        DOCKER_CMD+=(--mount "type=bind,source=$METADATA_PATH/entrypoint.sh,target=/entrypoint.sh,readonly")
    fi

    # Add container name and image
    [[ -n "$CONTAINER" ]] && DOCKER_CMD+=(--name "$CONTAINER")
    DOCKER_CMD+=("$CONTAINERIMAGE")

    # Execution Block
    if [[ "$DRY_RUN" == "1" ]]; then
        echo "TEST MODE: Action [Run Container]"
        echo "COMMAND: ${DOCKER_CMD[*]}"
    else
        if [[ "$VERBOSE" == "1" || "$DEBUG" == "1" ]]; then
            logservice "DEBUG" "${DOCKER_CMD[*]}"
        fi

        logservice "INFO" "Running container '${CONTAINERNAME}' with command '${DOCKER_CMD[*]}'."
        "${DOCKER_CMD[@]}"
    fi
}

##############################################################################
# ----------------------------- main entry --------------------------------- #
##############################################################################

ARGS=()
DRY_RUN=0
for arg in "$@"; do
    if [[ "$arg" == "--test" ]]; then
        DRY_RUN=1
    else
        ARGS+=("$arg")
    fi
done
set -- "${ARGS[@]}"

parse_cli OPERATION "$@"
dispatch "$OPERATION" run-container usage version
